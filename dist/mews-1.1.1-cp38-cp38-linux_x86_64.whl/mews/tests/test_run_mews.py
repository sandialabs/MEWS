#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 09:14:55 2022

@author: dlvilla
"""

import os
import numpy as np
from mews.run_mews import extreme_temperature
import unittest


class Test_Run_MEWS(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # clean this up HOW MUCH of this from Test_Alter is needed?
        cls.plot_results = True
        cls.write_results = False

        
        
    
    @classmethod
    def tearDownClass(cls):
        pass
    
    
    def test_run_mews_entire_call(self):
        # You must change example_dir to an absolute path to a copy of the MEWS repository 
        # examples folder if you move this script. 
        # any variable you put in the run_dict file location must be defined before calling extreme temperature
        example_dir = os.path.abspath(os.path.join(os.path.dirname(__file__)))

        # This must be a path to a valid run python dictionary text file. You can change the values 
        # in this long input file (very carefully to not corrupt the dictionary syntax) or you can just copy
        # and paste the dictionary here so that you can edit this input in an IDE.
        # The "only1file.dict" has the number of files to generate per case reduced to 1
        # use the "mews_run.dict" for a version that generate 200. You can change the input
        # to any value you want depending on how many files are needed.
        run_dict_file_path = os.path.join(os.path.dirname(__file__),"data_for_testing","mews_run_test.dict")
        
        """
        For this test only "Chicago" and "Houston" are defined

            "Chicago",
            "Baltimore",
            "Minneapolis",
            "Phoenix",
            'Miami',
            'Houston'
            'Atlanta', 
            'LasVegas',
            'LosAngeles',
            'SanFrancisco',
            'Albuquerque',
            'Seattle', 
            'Denver',
            'Helena', 
            'Duluth',
            'Fairbanks',
            'McAllen',
            'Kodiak',
            'Worcester'

        Any setting for Chicago applies for every city unless a command is repeated with 
        a new value. Some of the cities have to repeat different variables because of 
        differences in units.

        If you want to rerun an optimization (takes a full day on 60 processors for 
        the machines used so far), then do not include a city in neither of "skip_runs" 
        "only_generate_files". If you only want to generate files (much shorter run time
        in a matter of hours, then you only need to ) 

        """
        # first see if only_generate works
        results = extreme_temperature(run_dict=run_dict_file_path,
                                      only_generate_files=['Houston'],
                                      skip_runs=["Chicago"],num_cpu=-1, run_parallel=False,
                                      run_dict_var={"example_dir":example_dir})
        
        if "Run Failed Exception" in results["Houston"]:
            raise results["Houston"]["Run Failed Exception"]

        
        # next see if a full run works
        results = extreme_temperature(run_dict=run_dict_file_path,
                                      only_generate_files=[],generate_epw=False,
                                      skip_runs=["Chicago"],num_cpu=1, run_parallel=False,
                                      run_dict_var={"example_dir":example_dir})
        # this saves your results as a pickle so that you can see what went wrong if
        # you run this script as a batch script.

        if "Run Failed Exception" in results["Houston"]:
            raise results["Houston"]["Run Failed Exception"]
        
                                   

        

if __name__ == "__main__":
    profile = False
    
    if profile:
        import cProfile
        import pstats
        import io
        
        pr = cProfile.Profile()
        pr.enable()
        
    o = unittest.main(Test_Run_MEWS())
    
    if profile:

        pr.disable()
        s = io.StringIO()
        ps = pstats.Stats(pr, stream=s).sort_stats('tottime')
        ps.print_stats()
        
        with open('utilities_test_profile.txt', 'w+') as f:
            f.write(s.getvalue())