"""
The Multi-scenario Extreme Weather Simulator
testing module.
"""
from mews.tests.test_extreme_temperature_waves import Test_ExtremeTemperatureWaves

