#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 29 12:03:00 2022

@author: dlvilla
"""

import numpy as np
import matplotlib.pyplot as plt

lamb = 0.0001

def cdf_exponential(x,lamb,n):
    1-np.exp(-lamb*x)
    
    
fig,ax = plt.subplots(1,1,figsize=(10,10))

rr = np.arange(0,300)

ax.plot()
    
    

